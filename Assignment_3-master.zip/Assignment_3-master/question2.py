my_list=['rock','romen','dean','seth','miz','john']
my_list.append('google')
my_list.append('google')
my_list.append('apple')
my_list.append('facebook')
my_list.append('microsoft')
my_list.append('tesla')
print(my_list)