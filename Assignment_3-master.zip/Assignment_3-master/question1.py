our_list = []  # create empty list

first_num = int(input('Enter first number: '))
second_num = int(input('Enter second number: '))
third_num = int(input('Enter third number: '))

our_list.append(first_num)
our_list.append(second_num)
our_list.append(third_num)