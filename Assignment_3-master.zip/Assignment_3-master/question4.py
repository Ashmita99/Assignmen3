list=[9,8,7,6,5]
list.sort()
print(list)